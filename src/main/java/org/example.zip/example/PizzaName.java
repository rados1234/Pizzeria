package org.example;

public enum PizzaName {
    Pepperoni, Capriosa, Diavolla
}
