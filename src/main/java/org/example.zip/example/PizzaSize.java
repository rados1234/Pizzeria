package org.example;

public enum PizzaSize {
    mała, średnia, duża
}
