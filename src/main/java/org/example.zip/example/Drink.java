package org.example;

public class Drink extends Food{
    public Drink(String name) {
        this.name = name;
    }
}
