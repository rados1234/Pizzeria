package org.example;

public class Food {
    String name;

    @Override
    public String toString() {
        return "Food " +
                "name='" + name + '\'';
    }
}
